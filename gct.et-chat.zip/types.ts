
export enum Role {
  USER = 'user',
  BOT = 'bot'
}

export interface FileData {
  mimeType: string;
  data: string; // base64
  name?: string;
}

export interface UserIDData {
  name: string;
  age: string;
  gmail: string;
  institution: string;
  city: string;
  profileImage?: string; // base64 string
}

export interface Message {
  id: string;
  role: Role;
  content: string;
  timestamp: Date;
  fileData?: FileData;
  imageUri?: string; // For generated images
  idCardData?: UserIDData; // For ID Card feature
}

export interface ChatState {
  messages: Message[];
  isTyping: boolean;
  error: string | null;
}
