
import { GoogleGenAI, GenerateContentResponse, Chat, Modality } from "@google/genai";
import { SYSTEM_INSTRUCTION, APP_CONFIG } from "../constants.tsx";
import { FileData } from "../types.ts";

class GeminiService {
  private ai: GoogleGenAI;
  private chatSession: Chat | null = null;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  private initChat() {
    if (!this.chatSession) {
      this.chatSession = this.ai.chats.create({
        model: APP_CONFIG.MODEL_NAME,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          temperature: 0.7,
        },
      });
    }
    return this.chatSession;
  }

  async sendMessage(message: string, fileData?: FileData): Promise<string> {
    try {
      if (fileData) {
        const response = await this.ai.models.generateContent({
          model: APP_CONFIG.MODEL_NAME,
          contents: {
            role: 'user',
            parts: [
              { text: message || "Analyze this file." },
              {
                inlineData: {
                  mimeType: fileData.mimeType,
                  data: fileData.data
                }
              }
            ]
          },
          config: {
            systemInstruction: SYSTEM_INSTRUCTION
          }
        });
        return response.text || "I've analyzed the file but have no specific comments.";
      } else {
        const chat = this.initChat();
        const result = await chat.sendMessage({ message });
        return result.text || "I'm sorry, I couldn't generate a response.";
      }
    } catch (error) {
      console.error("Gemini API Error:", error);
      throw new Error("Uplink failed. Ensure your file size is reasonable and try again.");
    }
  }

  async translateText(text: string, targetLanguage: string): Promise<string> {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Translate the following text strictly into ${targetLanguage}. Maintain technical terms and the professional tone: "${text}"`,
        config: {
          temperature: 0.3,
        }
      });
      return response.text || text;
    } catch (error) {
      console.error("Translation Error:", error);
      return "Translation service unavailable.";
    }
  }

  async generateImage(prompt: string): Promise<string> {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: prompt }]
        }
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
      }
      throw new Error("No image data returned from neural core.");
    } catch (error) {
      console.error("Image Generation Error:", error);
      throw new Error("Neural synthesis failed.");
    }
  }

  async generateSpeech(text: string): Promise<string> {
    try {
      const response = await this.ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Read this clearly: ${text}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });
      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) throw new Error("No audio data");
      return base64Audio;
    } catch (error) {
      console.error("TTS Error:", error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();
