
import React, { useState, useRef, useEffect } from 'react';
import { Role, Message, ChatState, FileData, UserIDData } from './types.ts';
import { geminiService } from './services/geminiService.ts';
import MessageBubble from './components/MessageBubble.tsx';
import TypingIndicator from './components/TypingIndicator.tsx';
import IDCardCreator from './components/IDCardCreator.tsx';
import { APP_CONFIG, SUGGESTED_QUESTIONS } from './constants.tsx';

const App: React.FC = () => {
  const [state, setState] = useState<ChatState>({
    messages: [
      {
        id: 'initial',
        role: Role.BOT,
        content: `Greetings. I am **${APP_CONFIG.CHATBOT_NAME}**. Specialized in *Electrical Technology* and general intelligence. How can I assist your research today?`,
        timestamp: new Date()
      }
    ],
    isTyping: false,
    error: null
  });
  
  const [inputValue, setInputValue] = useState('');
  const [attachedFile, setAttachedFile] = useState<FileData | null>(null);
  const [isImageMode, setIsImageMode] = useState(false);
  const [showIDCreator, setShowIDCreator] = useState(false);
  const [userName, setUserName] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [state.messages, state.isTyping]);

  const startListening = () => {
    const Recognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
    
    if (!Recognition) {
      setState(prev => ({ ...prev, error: "Neural Voice Input not available in this browser environment." }));
      return;
    }

    const recognition = new Recognition();
    recognition.lang = 'en-US';
    recognition.interimResults = true;
    recognition.continuous = false;

    recognition.onstart = () => {
      setIsListening(true);
      if (window.navigator.vibrate) window.navigator.vibrate(50);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInputValue(transcript);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.onerror = (event: any) => {
      console.error("Speech Recognition Error:", event.error);
      setIsListening(false);
      if (event.error !== 'no-speech') {
        setState(prev => ({ ...prev, error: `Uplink failed: ${event.error}` }));
      }
    };

    recognition.start();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 20 * 1024 * 1024) {
      setState(prev => ({ ...prev, error: "File too large. Max 20MB." }));
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64Data = (reader.result as string).split(',')[1];
      setAttachedFile({
        mimeType: file.type,
        data: base64Data,
        name: file.name
      });
    };
    reader.readAsDataURL(file);
  };

  const handleIDSubmit = (data: UserIDData) => {
    setShowIDCreator(false);
    setUserName(data.name);
    
    const botMsg: Message = {
      id: Date.now().toString(),
      role: Role.BOT,
      content: `Hi **${data.name}**, how can I help you today? Your digital ID has been initialized successfully.`,
      timestamp: new Date(),
      idCardData: data
    };
    
    setState(prev => ({
      ...prev,
      messages: [...prev.messages, botMsg]
    }));
  };

  const handleSend = async (overrideText?: string) => {
    const text = overrideText || inputValue.trim();
    if ((!text && !attachedFile) || state.isTyping) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: Role.USER,
      content: text,
      timestamp: new Date(),
      fileData: attachedFile || undefined
    };

    setInputValue('');
    const currentFile = attachedFile;
    const currentMode = isImageMode;
    setAttachedFile(null);
    setIsImageMode(false);

    setState(prev => ({
      ...prev,
      messages: [...prev.messages, userMessage],
      isTyping: true,
      error: null
    }));

    try {
      let responseContent = "";
      let generatedImageUri = "";

      if (currentMode) {
        const enhancedPrompt = text.toLowerCase().includes('circuit') 
          ? `A professional electrical circuit schematic: ${text}. High contrast, glowing emerald lines, technical style.`
          : text;
        
        generatedImageUri = await geminiService.generateImage(enhancedPrompt || "A futuristic electrical schematic");
        responseContent = `Synthesis complete for: "${text}"`;
      } else {
        responseContent = await geminiService.sendMessage(text, currentFile || undefined);
      }

      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: Role.BOT,
        content: responseContent,
        timestamp: new Date(),
        imageUri: generatedImageUri || undefined
      };

      setState(prev => ({
        ...prev,
        messages: [...prev.messages, botMessage],
        isTyping: false
      }));
    } catch (err: any) {
      setState(prev => ({
        ...prev,
        isTyping: false,
        error: err.message || "Uplink interrupted. Please try again."
      }));
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <div className="relative h-[100dvh] w-full flex flex-col overflow-hidden bg-[#010409]">
      <header className="z-30 flex items-center justify-between px-5 py-4 bg-[#010409]/70 backdrop-blur-xl border-b border-white/5 shadow-lg safe-top">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <div className="absolute inset-0 bg-emerald-500 rounded-xl blur-xl opacity-20"></div>
            <div className="relative w-10 h-10 bg-[#0d1117] border border-white/10 rounded-xl flex items-center justify-center overflow-hidden">
               <div className="w-7 h-7 flex items-center justify-center">
                 <div className="absolute w-full h-full border border-emerald-400/50 rounded-full animate-spin"></div>
                 <div className="w-1.5 h-1.5 bg-white rounded-full shadow-[0_0_8px_#fff]"></div>
               </div>
            </div>
          </div>
          <div className="flex flex-col">
            <h1 className="text-xl font-black tracking-tight text-white leading-none">
              {APP_CONFIG.CHATBOT_NAME}
            </h1>
            <span className="text-[9px] text-emerald-400 font-black uppercase tracking-widest opacity-80 mt-1">Electrical AI</span>
          </div>
        </div>

        <div className="flex items-center space-x-2">
           <button onClick={() => setShowIDCreator(true)} className="w-10 h-10 flex items-center justify-center rounded-xl border border-white/10 bg-white/5 text-emerald-400 transition-transform active:scale-90">
             <i className="fas fa-id-card text-sm"></i>
           </button>
           <button onClick={() => setIsImageMode(!isImageMode)} className={`w-10 h-10 flex items-center justify-center rounded-xl border transition-all active:scale-90 ${isImageMode ? 'bg-emerald-500/20 border-emerald-400 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]' : 'bg-white/5 border-white/10 text-slate-400'}`}>
            <i className={`fas fa-wand-magic-sparkles text-sm`}></i>
          </button>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto scrollbar-hide py-6 px-3 space-y-5">
        {state.messages.map((msg) => (
          <MessageBubble key={msg.id} message={msg} />
        ))}
        {state.isTyping && <TypingIndicator />}
        {state.error && (
          <div className="mx-6 p-4 bg-rose-950/40 border border-rose-500/30 rounded-2xl text-rose-400 text-[11px] font-bold text-center shadow-[0_0_20px_rgba(244,63,94,0.2)] animate-pulse">
            <i className="fas fa-exclamation-triangle mr-2"></i>{state.error}
          </div>
        )}
        <div ref={messagesEndRef} className="h-10" />
      </main>

      {showIDCreator && <IDCardCreator onClose={() => setShowIDCreator(false)} onSubmit={handleIDSubmit} />}

      <footer className="z-30 p-4 pb-6 bg-[#010409]/95 backdrop-blur-3xl border-t border-white/5 safe-bottom shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
        <div className="max-w-xl mx-auto space-y-4">
          
          {!state.isTyping && state.messages.length < 20 && (
            <div className="flex overflow-x-auto scrollbar-hide space-x-2 pb-1">
              {SUGGESTED_QUESTIONS.map((q, idx) => (
                <button key={idx} onClick={() => handleSend(q)} className="whitespace-nowrap px-4 py-2.5 rounded-xl bg-white/5 border border-white/5 text-slate-400 text-[10px] font-black uppercase tracking-widest active:bg-emerald-500/30 active:text-white transition-all">
                  {q}
                </button>
              ))}
            </div>
          )}

          {attachedFile && (
            <div className="flex items-center space-x-3 p-2 bg-emerald-500/10 border border-emerald-400/30 rounded-xl w-fit shadow-xl animate-in fade-in zoom-in-95">
              <img src={`data:${attachedFile.mimeType};base64,${attachedFile.data}`} className="w-10 h-10 rounded-lg object-cover border border-white/10" />
              <div className="pr-2">
                <p className="text-[9px] text-slate-300 font-bold truncate max-w-[120px]">{attachedFile.name}</p>
                <p className="text-[8px] text-emerald-400 font-black uppercase">Buffered</p>
              </div>
              <button onClick={() => setAttachedFile(null)} className="text-slate-500 hover:text-white p-1"><i className="fas fa-times text-xs"></i></button>
            </div>
          )}

          <div className="flex items-center space-x-3">
            <div className="flex-1 relative">
              <div className={`
                flex items-center bg-[#0d1117]/80 border rounded-2xl overflow-hidden transition-all duration-300
                ${isListening ? 'border-emerald-400 shadow-[0_0_25px_rgba(16,185,129,0.2)]' : isImageMode ? 'border-cyan-500/40' : 'border-white/10'}
              `}>
                <input
                  ref={inputRef}
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={isListening ? "Listening to neural stream..." : userName ? `${userName}, command...` : "Command..."}
                  className="w-full bg-transparent py-4.5 px-6 text-white placeholder-slate-700 outline-none text-[15px] font-medium tracking-tight"
                  disabled={state.isTyping}
                />
                
                <div className="flex items-center pr-4 space-x-4">
                  <button 
                    onClick={startListening} 
                    className={`
                      w-10 h-10 flex items-center justify-center rounded-xl transition-all duration-500
                      ${isListening ? 'bg-emerald-500 text-white shadow-[0_0_20px_#10b981] animate-pulse' : 'text-slate-500 hover:text-emerald-400 active:scale-90'}
                    `}
                  >
                    <i className={`fas ${isListening ? 'fa-microphone' : 'fa-microphone-lines'} text-xl`}></i>
                  </button>
                  <button onClick={() => fileInputRef.current?.click()} className="text-slate-500 hover:text-cyan-400 active:scale-90">
                    <i className="fas fa-paperclip text-lg"></i>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*,application/pdf" onChange={handleFileChange} />
                  </button>
                </div>
              </div>
            </div>
            
            <button
              onClick={() => handleSend()}
              disabled={(!inputValue.trim() && !attachedFile) || state.isTyping}
              className={`
                w-14 h-14 flex items-center justify-center rounded-2xl transition-all duration-500 shadow-2xl active:scale-90
                ${(inputValue.trim() || attachedFile) && !state.isTyping 
                  ? 'bg-gradient-to-tr from-emerald-500 to-blue-600 text-white shadow-[0_0_25px_rgba(16,185,129,0.3)]' 
                  : 'bg-white/5 text-slate-800'
                }
              `}
            >
              <i className={`fas ${isImageMode ? 'fa-wand-magic-sparkles' : 'fa-bolt'} text-xl`}></i>
            </button>
          </div>

          <div className="pt-2 flex flex-col items-center space-y-3">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 px-4 py-1.5 bg-white/5 rounded-full border border-white/5">
                <span className="text-[9px] text-white/30 font-black uppercase tracking-widest">Protocol Creator</span>
                <span className="text-[10px] text-emerald-400 font-black tracking-[0.2em] uppercase glow-text">Muzamil</span>
              </div>
              <a href="https://www.facebook.com/share/1HnU5FCMGs/" target="_blank" className="w-9 h-9 flex items-center justify-center bg-white/5 rounded-full border border-white/5 active:bg-blue-600/20 active:border-blue-500/40 transition-all">
                <i className="fab fa-facebook-f text-xs text-blue-400"></i>
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
