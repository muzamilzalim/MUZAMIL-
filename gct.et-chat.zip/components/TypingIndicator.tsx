
import React from 'react';

const TypingIndicator: React.FC = () => {
  return (
    <div className="flex items-center space-x-1.5 p-3 px-4 rounded-2xl bg-slate-900/60 border border-cyan-500/20 w-max ml-4 mb-4 backdrop-blur-md shadow-[0_0_20px_rgba(34,211,238,0.1)]">
      <div className="flex space-x-1">
        <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full dot-anim shadow-[0_0_8px_#22d3ee]"></div>
        <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full dot-anim shadow-[0_0_8px_#22d3ee]" style={{ animationDelay: '0.2s' }}></div>
        <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full dot-anim shadow-[0_0_8px_#22d3ee]" style={{ animationDelay: '0.4s' }}></div>
      </div>
      <span className="text-[10px] text-cyan-300 ml-3 font-bold tracking-widest uppercase glow-text">Analyzing</span>
    </div>
  );
};

export default TypingIndicator;
