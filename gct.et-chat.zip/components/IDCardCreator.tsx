
import React, { useState, useRef } from 'react';
import { UserIDData } from '../types.ts';

interface IDCardCreatorProps {
  onClose: () => void;
  onSubmit: (data: UserIDData) => void;
}

const IDCardCreator: React.FC<IDCardCreatorProps> = ({ onClose, onSubmit }) => {
  const [formData, setFormData] = useState<UserIDData>({
    name: '',
    age: '',
    gmail: '',
    institution: '',
    city: '',
    profileImage: undefined
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.age || !formData.gmail || !formData.institution || !formData.city) return;
    onSubmit(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, profileImage: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0d1117] border-t sm:border border-white/10 rounded-t-[2.5rem] sm:rounded-[2rem] overflow-hidden shadow-2xl p-8 max-h-[90vh] overflow-y-auto scrollbar-hide">
        <div className="flex justify-between items-center mb-6">
          <div className="flex flex-col">
            <h2 className="text-2xl font-black text-white tracking-tighter">Digital Identity</h2>
            <span className="text-[10px] text-emerald-400 font-black uppercase tracking-widest mt-1">Initialization Protocol</span>
          </div>
          <button onClick={onClose} className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-slate-400 active:scale-90 transition-all">
            <i className="fas fa-times"></i>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Portrait Selection */}
          <div className="flex flex-col items-center space-y-2">
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="relative w-24 h-24 rounded-3xl border-2 border-dashed border-white/10 flex items-center justify-center cursor-pointer bg-white/5 overflow-hidden active:scale-95 transition-all"
            >
              {formData.profileImage ? (
                <img src={formData.profileImage} className="w-full h-full object-cover" />
              ) : (
                <i className="fas fa-camera text-xl text-white/20"></i>
              )}
            </div>
            <input type="file" ref={fileInputRef} onChange={handleImageChange} className="hidden" accept="image/*" />
            <span className="text-[9px] text-white/30 font-black uppercase tracking-widest">Select Portrait</span>
          </div>

          <div className="space-y-4">
            <div className="space-y-1">
              <label className="text-[9px] text-white/40 font-black uppercase tracking-widest ml-1">Full Name</label>
              <input 
                name="name" value={formData.name} onChange={handleChange} required
                placeholder="Enter name" 
                className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-5 text-white placeholder-white/20 outline-none focus:border-emerald-500/50"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[9px] text-white/40 font-black uppercase tracking-widest ml-1">Age</label>
                <input 
                  name="age" value={formData.age} onChange={handleChange} required
                  placeholder="22" 
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-5 text-white placeholder-white/20 outline-none focus:border-emerald-500/50"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[9px] text-white/40 font-black uppercase tracking-widest ml-1">City</label>
                <input 
                  name="city" value={formData.city} onChange={handleChange} required
                  placeholder="Islamabad" 
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-5 text-white placeholder-white/20 outline-none focus:border-emerald-500/50"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[9px] text-white/40 font-black uppercase tracking-widest ml-1">Gmail Address</label>
              <input 
                type="email" name="gmail" value={formData.gmail} onChange={handleChange} required
                placeholder="user@gmail.com" 
                className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-5 text-white placeholder-white/20 outline-none focus:border-emerald-500/50"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[9px] text-white/40 font-black uppercase tracking-widest ml-1">Institution</label>
              <input 
                name="institution" value={formData.institution} onChange={handleChange} required
                placeholder="University / College" 
                className="w-full bg-white/5 border border-white/10 rounded-xl py-4 px-5 text-white placeholder-white/20 outline-none focus:border-emerald-500/50"
              />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full mt-2 py-4 rounded-2xl bg-emerald-500 text-white font-black text-xs uppercase tracking-[0.2em] active:scale-95 transition-all shadow-lg shadow-emerald-500/20"
          >
            Initialize Account
          </button>
        </form>
        <div className="h-4 sm:hidden"></div>
      </div>
    </div>
  );
};

export default IDCardCreator;
