
import React, { useRef } from 'react';
import { UserIDData } from '../types.ts';

interface IDCardProps {
  data: UserIDData;
}

const IDCard: React.FC<IDCardProps> = ({ data }) => {
  const cardRef = useRef<HTMLDivElement>(null);

  const handleDownload = async () => {
    if (!cardRef.current) return;
    try {
      // @ts-ignore
      const canvas = await window.html2canvas(cardRef.current, {
        backgroundColor: '#0d1117',
        scale: 2,
        useCORS: true
      });
      const link = document.createElement('a');
      link.download = `GCT_ID_${data.name.replace(/\s+/g, '_')}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (err) {
      console.error("Download failed", err);
    }
  };

  return (
    <div className="flex flex-col items-center w-full px-2">
      <div ref={cardRef} className="relative w-full max-w-[320px] mx-auto group">
        <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500 via-blue-500 to-purple-500 rounded-2xl blur opacity-20 transition duration-1000"></div>
        
        <div className="relative glass-card rounded-2xl overflow-hidden border border-white/10 shadow-xl">
          <div className="bg-emerald-500/10 px-4 py-3 border-b border-white/5 flex justify-between items-center">
            <span className="text-[9px] text-emerald-400 font-black uppercase tracking-widest">Digital ID</span>
            <i className="fas fa-shield-halved text-emerald-500/40 text-xs"></i>
          </div>

          <div className="p-5 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-white/10 flex items-center justify-center overflow-hidden">
                {data.profileImage ? (
                  <img src={data.profileImage} alt={data.name} className="w-full h-full object-cover" />
                ) : (
                  <i className="fas fa-user text-xl text-white/30"></i>
                )}
              </div>
              <div className="flex flex-col">
                <h3 className="text-lg font-black text-white tracking-tight">{data.name}</h3>
                <p className="text-[9px] text-emerald-400 font-bold uppercase tracking-wider">{data.city}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 border-t border-white/5 pt-3">
              <div>
                <p className="text-[7px] text-white/20 font-black uppercase">Institution</p>
                <p className="text-[10px] text-slate-200 font-bold truncate">{data.institution}</p>
              </div>
              <div>
                <p className="text-[7px] text-white/20 font-black uppercase">Age</p>
                <p className="text-[10px] text-slate-200 font-bold">{data.age} YRS</p>
              </div>
            </div>

            <div>
              <p className="text-[7px] text-white/20 font-black uppercase">Registry Email</p>
              <p className="text-[10px] text-emerald-400/80 font-mono truncate lowercase">{data.gmail}</p>
            </div>
          </div>
          
          <div className="bg-white/5 px-4 py-1.5 flex items-center justify-between">
            <div className="flex space-x-1">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-1 w-2 bg-emerald-500 rounded-full opacity-40"></div>
              ))}
            </div>
            <span className="text-[7px] text-white/10 font-mono">ID: {Math.random().toString(36).substring(8).toUpperCase()}</span>
          </div>
        </div>
      </div>
      
      <button 
        onClick={handleDownload}
        className="mt-3 w-full max-w-[320px] py-3 bg-white/5 border border-white/10 rounded-xl text-emerald-400 text-[10px] font-black uppercase tracking-widest active:bg-emerald-500/10 transition-colors flex items-center justify-center space-x-2"
      >
        <i className="fas fa-cloud-arrow-down"></i>
        <span>Download Card</span>
      </button>
    </div>
  );
};

export default IDCard;
