
import React, { useState, useRef } from 'react';
import { Message, Role } from '../types.ts';
import { marked } from 'https://esm.sh/marked@12.0.0';
import IDCard from './IDCard.tsx';
import { geminiService } from '../services/geminiService.ts';

interface MessageBubbleProps {
  message: Message;
}

// PCM Decoding helpers
function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodePCM(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number = 24000,
  numChannels: number = 1,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.role === Role.USER;
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [activeWordIndex, setActiveWordIndex] = useState(-1);
  const [translatedText, setTranslatedText] = useState<string | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);
  
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);

  const getParsedContent = (content: string) => {
    return { __html: marked.parse(content, { breaks: true }) };
  };

  const isImageFile = message.fileData?.mimeType.startsWith('image/');

  const handleTranslate = async (lang: string) => {
    setIsTranslating(true);
    setShowLangMenu(false);
    try {
      const result = await geminiService.translateText(message.content, lang);
      setTranslatedText(result);
    } catch (err) {
      console.error("Translation failed", err);
    } finally {
      setIsTranslating(false);
    }
  };

  const handleSpeak = async () => {
    const textToSpeak = translatedText || message.content;
    if (isSpeaking) {
      audioSourceRef.current?.stop();
      setIsSpeaking(false);
      setActiveWordIndex(-1);
      return;
    }

    try {
      setIsSpeaking(true);
      const base64Audio = await geminiService.generateSpeech(textToSpeak);
      
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      
      const ctx = audioContextRef.current;
      const audioBytes = decodeBase64(base64Audio);
      const audioBuffer = await decodePCM(audioBytes, ctx);
      
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      audioSourceRef.current = source;

      const words = textToSpeak.split(/\s+/).filter(w => w.length > 0);
      const duration = audioBuffer.duration;
      const msPerWord = (duration * 1000) / words.length;

      source.onended = () => {
        setIsSpeaking(false);
        setActiveWordIndex(-1);
      };

      source.start();

      let startTime = Date.now();
      const interval = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const index = Math.floor(elapsed / msPerWord);
        if (index < words.length && isSpeaking) {
          setActiveWordIndex(index);
        } else {
          clearInterval(interval);
        }
      }, 50);

    } catch (err) {
      console.error("Speech playback failed", err);
      setIsSpeaking(false);
      setActiveWordIndex(-1);
    }
  };

  const renderContent = () => {
    const textToRender = translatedText || message.content;

    if (activeWordIndex === -1) {
      return (
        <div 
          className={`markdown-content prose prose-invert ${isTranslating ? 'animate-pulse opacity-50' : 'animate-in fade-in duration-500'}`} 
          dangerouslySetInnerHTML={getParsedContent(textToRender)} 
        />
      );
    }

    const words = textToRender.split(/(\s+)/);
    let wordCounter = 0;
    return (
      <div className="markdown-content prose prose-invert leading-relaxed">
        {words.map((part, i) => {
          if (/\s+/.test(part)) return <span key={i}>{part}</span>;
          const isCurrent = wordCounter === activeWordIndex;
          wordCounter++;
          return (
            <span key={i} className={isCurrent ? 'word-active scale-110 transition-transform' : 'transition-colors duration-300'}>
              {part}
            </span>
          );
        })}
      </div>
    );
  };

  return (
    <div className={`flex w-full px-2 ${isUser ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
      <div className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} max-w-[92%]`}>
        
        {message.fileData && isImageFile && (
          <div className="mb-2 relative group">
            <div className="absolute inset-0 bg-emerald-500/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <img src={`data:${message.fileData.mimeType};base64,${message.fileData.data}`} className="relative max-w-[240px] rounded-2xl border border-white/10 shadow-2xl" />
          </div>
        )}

        {message.imageUri && (
          <div className="mb-3 relative group">
             <div className="absolute inset-0 bg-cyan-500/20 blur-2xl animate-pulse"></div>
             <img src={message.imageUri} className="relative max-w-full rounded-2xl border border-cyan-500/40 shadow-[0_0_30px_rgba(34,211,238,0.2)]" />
          </div>
        )}

        {message.idCardData && <IDCard data={message.idCardData} />}

        {!message.idCardData && message.content && (
          <div className={`
            relative p-5 rounded-[2rem] text-[15px] shadow-2xl transition-all duration-500
            ${isUser 
              ? 'bg-gradient-to-br from-blue-600 to-blue-700 text-white rounded-tr-none border border-white/10' 
              : 'glass-card breathe-emerald text-slate-100 rounded-tl-none border-emerald-500/30'
            }
          `}>
            {renderContent()}
            
            <div className="flex items-center justify-between mt-4 space-x-2">
              <span className={`text-[9px] font-black uppercase tracking-widest opacity-40 ${isUser ? 'text-white' : 'text-emerald-400'}`}>
                {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
              
              {!isUser && (
                <div className="flex items-center space-x-2 relative">
                  
                  {translatedText && (
                    <button 
                      onClick={() => setTranslatedText(null)}
                      className="px-2.5 py-1.5 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-400 text-[9px] font-black uppercase tracking-widest transition-all hover:bg-rose-500/20 active:scale-95 shadow-sm"
                    >
                      Original
                    </button>
                  )}

                  <div className="relative">
                    <button 
                      onClick={() => setShowLangMenu(!showLangMenu)}
                      className={`flex items-center space-x-2 px-3 py-1.5 rounded-xl border transition-all active:scale-95 shadow-lg ${isTranslating ? 'bg-cyan-500/20 border-cyan-400 text-cyan-400 shadow-[0_0_15px_rgba(34,211,238,0.2)]' : 'bg-white/5 border-white/10 text-slate-400 hover:text-cyan-400 hover:border-cyan-500/40'}`}
                    >
                      <i className={`fas ${isTranslating ? 'fa-spinner fa-spin' : 'fa-language'} text-[11px]`}></i>
                      <span className="text-[9px] font-black uppercase tracking-widest">{isTranslating ? '...' : 'Translate'}</span>
                    </button>

                    {/* Language Selector Menu - POSITIONED BELOW THE BUTTON */}
                    {showLangMenu && (
                      <div className="absolute top-full mt-2 right-0 bg-[#0d1117]/95 backdrop-blur-2xl border border-emerald-500/40 rounded-2xl p-2.5 flex flex-col space-y-1 shadow-[0_20px_50px_rgba(0,0,0,0.8)] z-[60] animate-in slide-in-from-top-4 fade-in scale-95 origin-top-right min-w-[150px] neon-border">
                        <div className="text-[8px] font-black uppercase tracking-widest text-emerald-500/60 px-3 pb-2 border-b border-white/5 mb-1.5 flex items-center justify-between">
                          <span>Target Stream</span>
                          <i className="fas fa-globe-asia animate-pulse"></i>
                        </div>
                        {['Spanish', 'Urdu', 'Arabic', 'Hindi', 'Pashto'].map(lang => (
                          <button 
                            key={lang}
                            onClick={() => handleTranslate(lang)}
                            className="px-4 py-2.5 text-[11px] font-black uppercase tracking-widest text-slate-300 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-xl transition-all text-left flex items-center justify-between group active:scale-95"
                          >
                            <span>{lang}</span>
                            <i className="fas fa-arrow-right text-[8px] opacity-0 group-hover:opacity-100 -translate-x-2 group-hover:translate-x-0 transition-all text-emerald-500"></i>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  <button 
                    onClick={handleSpeak}
                    className={`
                      flex items-center space-x-2 px-3 py-1.5 rounded-xl border transition-all duration-300 shadow-lg active:scale-95
                      ${isSpeaking 
                        ? 'bg-emerald-500/20 border-emerald-400 text-emerald-400 shadow-[0_0_15px_rgba(16,185,129,0.4)] scale-105' 
                        : 'bg-white/5 border-white/10 text-slate-400 hover:text-emerald-400 hover:border-emerald-500/40'
                      }
                    `}
                  >
                    <div className={`w-1.5 h-1.5 rounded-full ${isSpeaking ? 'bg-emerald-400 animate-ping shadow-[0_0_8px_#10b981]' : 'bg-slate-600'}`}></div>
                    <i className={`fas ${isSpeaking ? 'fa-stop' : 'fa-volume-up'} text-[11px]`}></i>
                    <span className="text-[9px] font-black uppercase tracking-widest">{isSpeaking ? 'Stop' : 'Listen'}</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MessageBubble;
